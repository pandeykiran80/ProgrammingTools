# Python 3.7
"""
Program to calculate an area of triangle and rectangle
from the input provided
area of rectangle, A = b*c
area of triangle, A= 0.5*h_b*b
@author: Kiran Pandey
"""
#======================================
#           modules
#======================================
import numpy as np
#======================================
#            For Rectangle
#======================================
#---------------Parameters-------------
b = float(input( "Provide length of rectangle: "))
c = float(input( "Provide breadth of rectangle: ")) 

#------------my fct--------------------
def area_rectangle(b,c):
    return b*c

#---------------Calculation-------------
A = area_rectangle(b,c)
print('Area of rectangle is ' +str(A) + ' units.')

#======================================
#            For Triangle
#======================================
#---------------Parameters-------------
h_b = float(input( "Provide height of triangle: "))
b = float(input( "Provide width of triangle: ")) 

#------------my fct--------------------
def area_triangle(h_b,b):
    return 0.5*h_b*b

#---------------Calculation-------------
A = area_triangle(h_b,b)
print('Area of triangle is ' +str(A) + ' units.')
