# Python 3.7
"""
create a function that takes an vertices of a polygon
and calculates area
@author: Kiran Pandey
"""
#=====================================================================
#                   modules
#=====================================================================
import numpy as np

#-------------------Parameters-------------------------------------------
#Vertices
x = [1,3,4,3.5,2]
y = [1,1,2,5,4]

#------------my fct--------------------
def area_polygon(x,y):
  n = len(x)
  A = (( x[n-1]*y[0]) - (x[0]*y[n-1] ))/2 # formula to calculate area
  for i in range(0,n-1,1):
      A +=(( x[i]*y[i+1]) - (x[i+1]*y[i]))/2          
  return A
 #------------area computation--------------------
A = float(area_polygon(x,y))
print("")
print("Area of given polygon is = " + str(A) + " units")

#-------------------Test case.-------------------------------------------
###Verticies of polygon with rectangle(one coordinate added(0,3)) and triangle

#Rectangle
x = [0,2,2,0]
y = [0,0,3,3]

## area computation
area = float(area_polygon(x,y))
print("")
print("Area of given rectangle is = " + str(area) + " units")

#Triangle
x = [3,2,0]
y = [1,3,1]

## area computation
area = float(area_polygon(x,y))
print("")
print("Area of given triangle is = " + str(area) + " units")

