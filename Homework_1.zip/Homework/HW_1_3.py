# Python 3.7
"""
Circle and rectangle HW1_3 programming tools
@author: Kiran Pandey
"""
#=====================================================================
#                   modules
#=====================================================================
import numpy as np

#------------parameters--------------------
r = 12.6 # radius of circle, mm
a = 1.5 # one side of rectangle, mm
# b = ?, we have to find

 #------------computation--------------------
# area of circle
area_c = 3.14*(r**2) # pi*r^2
b=0  # initializing b, the side to be calculated
while a*b < area_c:  # area of rectangle should be less than area of circle
    b += 1
print ("The largest possible value of b:", b,'mm')