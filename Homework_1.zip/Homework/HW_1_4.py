## Python 3.7
#"""
#Radioactivity HW1_4
#@author: Kiran Pandey
#"""
##=====================================================================
##                   modules
##=====================================================================
import numpy as np
import math as m

"""HW_1_4_a"""
#------------my fct--------------------
def radioactivity_decay(N_0,T,t_half):
    return N_0*m.exp(-(T/t_half))
#======================================
#           parameters
#======================================
T = float(input( "Provide elapsed time (in years) of radioactive substance: "))
t_half = float(input( "Provide half life (in years) of radioactive substance: "))
N0_def = 1
N_0 = input("Enter initial value of N0 at time t0: ")
if not N_0:
    N_0 = N0_def
N_0 = float(N_0)

N_Frac = radioactivity_decay(N_0,T,t_half)
print('Fractional amout of the radioactive subtance is %0.4f' %N_Frac, 'units.')


""" HW_1_4_b"""
#======================================
#           parameters
#======================================
t_half = [5690, 5770]  # max and min half life, years
T=[10000,100000,1000000]  # elapsed time,  years

N_Fraction_5690=[]
N_Fraction_5770=[]

#------------my fct--------------------
def radioactivity_Frac(T,t_half):
    return m.exp(-(T/t_half))
#=====================================================
#                   Matrix setup and computation
N_Frac=np.ones((len(T),len(t_half)))
for i in range(len(T)):
    N_Fraction_5690.append(m.exp(-T[i]/t_half[0]))
    N_Fraction_5770.append(m.exp(-T[i]/t_half[1]))
    N_Frac[i][0]=N_Fraction_5690[i]
    N_Frac[i][1]=N_Fraction_5770[i]

print('')
print( "The fractional amounts remaining after 10Kyr with half life of 5690 and 5770 years are:", N_Frac[0][0],N_Frac[0][1], "units respectively.")      
print('')
print( "The fractional amounts remaining after 100Kyr with half life of 5690 and 5770 years are:", N_Frac[1][0],N_Frac[1][1], "units respectively.")
print('')
print( "The fractional amounts remaining after 1Myr with half life of 5690 and 5770 years are:", N_Frac[2][0],N_Frac[2][1], "units respectively.")

"""HW_1_4_c"""

print('')
print('Hereafter the script asks for elasped time (T) and half-life (t_half) as an input.')
# Parameters
T = float(input( "Provide elapsed time (in years) of radioactive substance: "))
t_half = float(input( "Provide half life (in years) of radioactive substance: "))
# Computation
N_Frac = radioactivity_Frac(T,t_half)
print('')
print('The fractional amount of 14C based on the input T and t_half is %0.4f' %N_Frac, 'units.' )


    




  