Seismicity catalogs:
hs_1981_2011_all.mat - Southern California matlab binary

From:
Hauksson, Egill, Wenzheng Yang, and Peter M. Shearer. "Waveform relocated earthquake catalog for southern California (1981 to June 2011)." Bulletin of the Seismological Society of America 102.5 (2012): 2239-2244.

See also:
https://scedc.caltech.edu/research-tools/altcatalogs.html
