python source code:

 -FMD_GR.py contains the class FMD
